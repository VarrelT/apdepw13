﻿namespace Take_Home_ApDev_Week_14
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_matchid = new System.Windows.Forms.TextBox();
            this.cb_teamhome = new System.Windows.Forms.ComboBox();
            this.cb_teamaway = new System.Windows.Forms.ComboBox();
            this.dtp_matchdate = new System.Windows.Forms.DateTimePicker();
            this.dgv_dmatch = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_dmatch)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(60, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Match ID :";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(60, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Team Home :";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(443, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "Team Away :";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(443, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 26);
            this.label4.TabIndex = 2;
            this.label4.Text = "Match Date :";
            // 
            // tb_matchid
            // 
            this.tb_matchid.Location = new System.Drawing.Point(178, 68);
            this.tb_matchid.Name = "tb_matchid";
            this.tb_matchid.Size = new System.Drawing.Size(162, 26);
            this.tb_matchid.TabIndex = 4;
            // 
            // cb_teamhome
            // 
            this.cb_teamhome.FormattingEnabled = true;
            this.cb_teamhome.Location = new System.Drawing.Point(178, 114);
            this.cb_teamhome.Name = "cb_teamhome";
            this.cb_teamhome.Size = new System.Drawing.Size(162, 28);
            this.cb_teamhome.TabIndex = 5;
            this.cb_teamhome.SelectedIndexChanged += new System.EventHandler(this.cb_teamhome_SelectedIndexChanged);
            // 
            // cb_teamaway
            // 
            this.cb_teamaway.FormattingEnabled = true;
            this.cb_teamaway.Location = new System.Drawing.Point(612, 117);
            this.cb_teamaway.Name = "cb_teamaway";
            this.cb_teamaway.Size = new System.Drawing.Size(182, 28);
            this.cb_teamaway.TabIndex = 6;
            this.cb_teamaway.SelectedIndexChanged += new System.EventHandler(this.cb_teamaway_SelectedIndexChanged);
            // 
            // dtp_matchdate
            // 
            this.dtp_matchdate.Location = new System.Drawing.Point(612, 71);
            this.dtp_matchdate.Name = "dtp_matchdate";
            this.dtp_matchdate.Size = new System.Drawing.Size(315, 26);
            this.dtp_matchdate.TabIndex = 7;
            this.dtp_matchdate.ValueChanged += new System.EventHandler(this.dtp_matchdate_ValueChanged);
            // 
            // dgv_dmatch
            // 
            this.dgv_dmatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_dmatch.Location = new System.Drawing.Point(64, 201);
            this.dgv_dmatch.Name = "dgv_dmatch";
            this.dgv_dmatch.RowHeadersWidth = 62;
            this.dgv_dmatch.RowTemplate.Height = 28;
            this.dgv_dmatch.Size = new System.Drawing.Size(440, 236);
            this.dgv_dmatch.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(530, 247);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "Team :";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(530, 201);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 23);
            this.label6.TabIndex = 9;
            this.label6.Text = "Minute :";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(530, 332);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 28);
            this.label7.TabIndex = 12;
            this.label7.Text = "Type :";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(530, 289);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 28);
            this.label8.TabIndex = 11;
            this.label8.Text = "Player : ";
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(621, 198);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(182, 26);
            this.tb_minute.TabIndex = 13;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(621, 244);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(182, 28);
            this.cb_team.TabIndex = 14;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(621, 286);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(182, 28);
            this.cb_player.TabIndex = 15;
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(621, 332);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(182, 28);
            this.cb_type.TabIndex = 16;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(546, 384);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(98, 40);
            this.btn_add.TabIndex = 17;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(650, 384);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(98, 40);
            this.btn_delete.TabIndex = 18;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(297, 460);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(98, 40);
            this.btn_insert.TabIndex = 19;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(996, 527);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgv_dmatch);
            this.Controls.Add(this.dtp_matchdate);
            this.Controls.Add(this.cb_teamaway);
            this.Controls.Add(this.cb_teamhome);
            this.Controls.Add(this.tb_matchid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_dmatch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_matchid;
        private System.Windows.Forms.ComboBox cb_teamhome;
        private System.Windows.Forms.ComboBox cb_teamaway;
        private System.Windows.Forms.DateTimePicker dtp_matchdate;
        private System.Windows.Forms.DataGridView dgv_dmatch;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_insert;
    }
}

