﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Take_Home_ApDev_Week_14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection connect;
        MySqlCommand command;
        MySqlDataAdapter adapter;

        DataTable teamhome = new DataTable();
        DataTable teamaway = new DataTable();
        DataTable datamatch = new DataTable();
        string query;

        private void Form1_Load(object sender, EventArgs e)
        {
            connect = new MySqlConnection("server = localhost; uid = root; pwd = Artnote2605; database = premier_league");
            connect.Open();

            try
            {
                query = "select team_name, team_id from team;";
                command = new MySqlCommand(query, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(teamhome);
                cb_teamhome.DataSource = teamhome;
                cb_teamhome.DisplayMember = "team_name";
                cb_teamhome.ValueMember = "team_id";

                query = "select team_name, team_id from team;";
                command = new MySqlCommand(query, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(teamaway);
                cb_teamaway.DataSource = teamaway;
                cb_teamaway.DisplayMember = "team_name";
                cb_teamaway.ValueMember = "team_id";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            cb_type.Items.Add("GO");
            cb_type.Items.Add("GP");
            cb_type.Items.Add("GW");
            cb_type.Items.Add("CR");
            cb_type.Items.Add("CY");
            cb_type.Items.Add("PM");

            datamatch.Columns.Add("Minute");
            datamatch.Columns.Add("Team");
            datamatch.Columns.Add("Player");
            datamatch.Columns.Add("Type");

            dgv_dmatch.DataSource = datamatch;

        }

        private void cb_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_team.Items.Clear();
            if (cb_teamhome.Text == cb_teamaway.Text)
            {
                MessageBox.Show("Team Sama");
            }
            else
            {
                cb_team.Items.Add(cb_teamhome.Text);
                cb_team.Items.Add(cb_teamaway.Text);
            }
        }

        private void cb_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_team.Items.Clear();
            if (cb_teamhome.Text == cb_teamaway.Text)
            {
                MessageBox.Show("Team Sama");
            }
            else
            {
                cb_team.Items.Add(cb_teamhome.Text);
                cb_team.Items.Add(cb_teamaway.Text);
            }

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            datamatch.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dr in dgv_dmatch.SelectedRows)
            {
                dgv_dmatch.Rows.RemoveAt(dr.Index);
            }

        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable player = new DataTable();
            string query = "select player_name from player left join team on team.team_name = '" + cb_team.Text + "' where player.team_id = team.team_id AND status = 1 group by player_name";
            command = new MySqlCommand(query, connect);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player";
            cb_player.ValueMember = "player_name";
        }

        string teamid;
        string playerid;

        private void btn_insert_Click(object sender, EventArgs e)
        {
            if (tb_minute.Text == "" || cb_team.Text == "" || cb_player.Text == "" || cb_type.Text == "")
            {
                MessageBox.Show("Data belum lengkap");
            }
            else
            {
                try
                {
                    DateTime selectedDate = dtp_matchdate.Value;
                    string matchdate = selectedDate.ToString("yyyy-MM-dd");
                    for (int i = 0; i < datamatch.Rows.Count; i++)
                    {
                        DataTable idteam = new DataTable();
                        query = $"select team_id from team where team_name = '{datamatch.Rows[i][1]}'";
                        command = new MySqlCommand(query, connect);
                        adapter = new MySqlDataAdapter(command);
                        adapter.Fill(idteam);
                        if (idteam.Rows.Count > 0)
                        {
                            teamid = idteam.Rows[0][0].ToString();
                        }

                        DataTable idplayer = new DataTable();
                        query = $"select player_id from player where player_name = '{datamatch.Rows[i][2]}'";
                        command = new MySqlCommand(query, connect);
                        adapter = new MySqlDataAdapter(command);
                        adapter.Fill(idplayer);
                        if (idplayer.Rows.Count > 0)
                        {
                            playerid = idplayer.Rows[0][0].ToString();
                        }


                        query = $"insert into dmatch (`match_id`,`minute`,`team_id`,`player_id`,`type`,`delete`) values ({tb_matchid.Text},{datamatch.Rows[i][0].ToString()},'{teamid}','{playerid}','{datamatch.Rows[i][3].ToString()}',0)";
                        command = new MySqlCommand(query, connect);
                        adapter = new MySqlDataAdapter (command);
                        command.ExecuteNonQuery();

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                //query = $"insert into `match` (`match_id`,`match_date`,`team_home`,`team_away`,`goal_home`,`goal_away`,`referee_id`,`delete`) values ({tb_matchid.Text},'{matchdate}',{cb_teamhome.Text},'{cb_teamaway.Text}','M002',0)";
                //command = new MySqlCommand(query, connect);
                //command.ExecuteNonQuery();

            }
        }

        DataTable matchid = new DataTable();
        private void dtp_matchdate_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                matchid.Rows.Clear();
                string year = dtp_matchdate.Text.Remove(0,dtp_matchdate.Text.Length - 4);
                string idquery = "select m.match_id from `match` m where m.match_id LIKE '" + year + "%' order by m.match_id;";
                command = new MySqlCommand(idquery, connect);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(matchid);
                if (matchid.Rows.Count > 0 )
                {
                    int id = Convert.ToInt32(matchid.Rows[matchid.Rows.Count - 1][0].ToString());
                    tb_matchid.Text = (id + 1).ToString();
                }
                else
                {
                    MessageBox.Show("Pilih tahun diantara 2015 atau 2016");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
